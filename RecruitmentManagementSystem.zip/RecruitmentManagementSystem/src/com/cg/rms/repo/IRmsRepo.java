package com.cg.rms.repo;
import com.cg.rms.bean.CandidatePersonal;
import com.cg.rms.bean.CompanyMaster;

public interface IRmsRepo {
	public CandidatePersonal addCandidate(CandidatePersonal cpersonal);	
	public CompanyMaster addCompany(CompanyMaster cmaster);
}
