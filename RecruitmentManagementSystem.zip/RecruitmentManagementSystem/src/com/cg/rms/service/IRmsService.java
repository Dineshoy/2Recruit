package com.cg.rms.service;

import com.cg.rms.bean.CandidatePersonal;
import com.cg.rms.bean.CompanyMaster;

public interface IRmsService {
	
	public CandidatePersonal addCandidate(CandidatePersonal cpersonal);
	public CompanyMaster addCompany(CompanyMaster cmaster);

}
